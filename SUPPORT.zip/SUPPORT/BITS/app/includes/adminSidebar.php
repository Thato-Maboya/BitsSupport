<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/postsIndex.php' ?>">Manage HJH</a></li>
        <li><a href="<?php echo BASE_URL . '/usersIndex.php' ?>">Manage CMJAH</a></li>
        <li><a href="<?php echo BASE_URL . '/topicsIndex.php' ?>">Manage CHBAH</a></li>
        <li><a href="<?php echo BASE_URL . '/tower.php' ?>">Manage All Tower</a></li>
        <li><a href="<?php echo BASE_URL . '/printer.php' ?>">Manage All Printer</a></li>
        <li><a href="<?php echo BASE_URL . '/monitor.php' ?>">Manage All Monitor</a></li>
        <li><a href="<?php echo BASE_URL . '/teamIndex.php' ?>">Manage User/Office Items</a></li>
        <li><a href="<?php echo BASE_URL . '/dispute.php' ?>">Deleted User/Office Items</a></li>
        <li><a href="<?php echo BASE_URL . '/users.php' ?>">Manage User</a></li>
        <li><a href="<?php echo BASE_URL . '/todo.php' ?>">To do lists</a></li>
        <li><a href="<?php echo BASE_URL . '/dashboard.php' ?>">Dashboard</a></li>
    </ul>
</div>