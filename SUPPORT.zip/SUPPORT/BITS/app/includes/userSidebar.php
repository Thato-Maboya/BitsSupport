<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/usersHJHindex.php' ?>">Manage HJH</a></li>
        <li><a href="<?php echo BASE_URL . '/usersCMJAHindex.php' ?>">Manage CMJAH</a></li>
        <li><a href="<?php echo BASE_URL . '/usersCHBAHindex.php' ?>">Manage CHBAH</a></li>
        <li><a href="<?php echo BASE_URL . '/user_tower.php' ?>">Manage All Tower</a></li>
        <li><a href="<?php echo BASE_URL . '/user_printer.php' ?>">Manage All Printer</a></li>
        <li><a href="<?php echo BASE_URL . '/user_monitor.php' ?>">Manage All Monitor</a></li>
        <li><a href="<?php echo BASE_URL . '/user_teamIndex.php' ?>">Manage User/Office Items</a></li>
        <li><a href="<?php echo BASE_URL . '/user_dispute.php' ?>">Deleted User/Office Items</a></li>
        <li><a href="<?php echo BASE_URL . '/usersTodo.php' ?>">To do lists</a></li>
        <li><a href="<?php echo BASE_URL . '/usersdashboard.php' ?>">Dashboard</a></li>
    </ul>
</div>