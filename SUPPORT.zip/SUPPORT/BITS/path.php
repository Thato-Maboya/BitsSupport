<?php

define("ROOT_PATH", realpath(dirname('_FILE_')));
define("BASE_URL", "http://localhost:8080/dashboard/SUPPORT/BITS");